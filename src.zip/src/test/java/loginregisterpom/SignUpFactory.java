package loginregisterpom;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUpFactory extends Factory {
	
	public SignUpFactory(WebDriver iDriver) 
	{
		super(iDriver);
	}

	public void SIGNUP(String phno,String pass,String conpass) throws Exception
	{
		//String dataA[]=data.split(",");
		WebElement ele = driver.findElement(property.getElement("HOVER"));
		//Create object 'action' of an Actions class
		Actions action = new Actions(driver);
		//Mouseover on an element
		action.moveToElement(ele).perform();
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("REGISTER"))));
		driver.findElement(property.getElement("REGISTER")).click();
		driver.findElement(property.getElement("EMAIL_MOBILE")).click();
		driver.findElement(property.getElement("EMAIL_MOBILE")).sendKeys(phno);
		driver.findElement(property.getElement("REGISTERBUTTON")).click();	
		WebDriverWait wt1=new WebDriverWait(driver, 50);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("OTP"))));
		driver.findElement(property.getElement("OTP")).sendKeys("1134");
		driver.findElement(property.getElement("PASS")).sendKeys(pass);
		driver.findElement(property.getElement("CONPASS")).sendKeys(conpass);
		//driver.findElement(property.getElement("SUBMIT")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver.findElement(property.getElement("SUBMIT")).click();
		/*try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		WebDriverWait wt2=new WebDriverWait(driver, 50);
		wt2.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("EMAIL_BASIC"))));
		driver.findElement(property.getElement("EMAIL_BASIC")).sendKeys(phno);;
		driver.findElement(property.getElement("PASSWORD_BASIC")).sendKeys(pass);;
		driver.findElement(property.getElement("LOGIN")).click();
}
}
