package flightroundwaypom;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import loginregisterpom.Factory;
public class FlightBookRound extends Factory{
	
	public FlightBookRound(WebDriver iDriver)
	{
		super(iDriver);
	}
	
	public void flightBook()
	{
		Assert.assertEquals(driver.getTitle(), "RoundTrip Lowest Airfare, Flight Tickets, Cheap Air Tickets � EaseMyTrip.com");
		System.out.println("Page 2 is open");
		Actions action= new Actions(driver);
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(property.getElement("B_AIRLINE")));

//		driver.findElement(property.getElement("B_AIRLINE")).click();
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(property.getElement("B_AIRLINE")));
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		driver.findElement(property.getElement("B_AIRWAYS")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		
		driver.findElement(property.getElement("B_DEPART")).click();
		driver.findElement(property.getElement("B_RETURN")).click();
	
		driver.findElement(property.getElement("B_BOOKNOW")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		}
}
