package flightroundwaypom;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import loginregisterpom.Factory;
public class SearchRoundFactory extends Factory{

		public SearchRoundFactory(WebDriver iDriver)
		{
			super(iDriver);
		}
		public void flightSearch(String source,String destination)
			{
			Assert.assertEquals(driver.getTitle(), "Book Flights, Hotels, Bus Tickets & Holidays - EaseMyTrip.com");
			System.out.println("Page 1 is open");
				Actions action= new Actions(driver);
				driver.findElement(By.xpath("//li[text()='Round Trip']")).click();;
				//driver.findElement(property.getElement("S_SOURCE")).click();
				driver.findElement(property.getElement("S_SOURCE")).clear();
				driver.findElement(property.getElement("S_SOURCE")).sendKeys(source);
				
				new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']/li/div")));
				
				driver.findElement(By.xpath("//ul[@id='ui-id-1']/li/div")).click();
			
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				driver.findElement(property.getElement("S_DESTINATION")).click();
		  	    driver.findElement(property.getElement("S_DESTINATION")).sendKeys(destination);
		  	    
		  	  new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-2']/li/div")));
				
				driver.findElement(By.xpath("//ul[@id='ui-id-2']/li/div")).click();
	
		//		action.moveToElement(E1).click(E1).perform();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				driver.findElement(property.getElement("S_DATE")).click();
				driver.findElement(By.xpath("//li[contains(@id,'20/04/2019')]")).click();
				
				
				driver.findElement(property.getElement("S_RDATE")).click();
				driver.findElement(By.xpath("//li[contains(@id,'27/04/2019')]")).click();
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				driver.findElement(property.getElement("S_TRAVELLER")).click();
				driver.findElement(property.getElement("S_ADULT")).click();
				driver.findElement(property.getElement("S_CHILD")).click();
				driver.findElement(property.getElement("S_INFANT")).click();
				driver.findElement(property.getElement("S_CLASS")).click();
				//driver.findElement(property.getElement("S_DONE")).click();
				//new Select(driver.findElement(property.getElement("EOW_Time"))).selectByIndex(1);
				driver.findElement(By.id("search")).click();
				
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.id("BtnBookNow")));
				
			}			
	}
		

