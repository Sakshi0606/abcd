package flightonewaypom;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import loginregisterpom.Factory;
public class FlightBookOneWay extends Factory{
	
	public FlightBookOneWay(WebDriver iDriver)
	{
		super(iDriver);
	}
	
	public void flightBook()
	{
		Actions action= new Actions(driver);
		
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(property.getElement("B_AIRLINE")));

//		driver.findElement(property.getElement("B_AIRLINE")).click();
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(property.getElement("B_AIRLINE")));
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		driver.findElement(property.getElement("B_AIRWAYS")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		
		driver.findElement(property.getElement("B_BOOKNOW")).click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		}
}
