package flightonewaypom;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import util.LoadProperty;

import loginregisterpom.Factory;

public class EnterOneWayTraveller extends Factory {
	public EnterOneWayTraveller(WebDriver iDriver)
	{
		super(iDriver);
	}
	public void enterDetails(Object[][] data) throws Exception
	{
	Actions action= new Actions(driver);
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("txtFNAdult0")));
	  Thread.sleep(4000);
	  System.out.println("scrolled");
	  Thread.sleep(4000);
	driver.findElement(property.getElement("T_TITLE1")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_MISS1")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_TRAVELLER1FNAME")).sendKeys(data[0][0].toString());
	driver.findElement(property.getElement("T_TRAVELLER1LNAME")).sendKeys(data[0][1].toString());
	
	//TRAVLLER2
	driver.findElement(property.getElement("T_TITLE2")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_MISS2")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_TRAVELLER2FNAME")).sendKeys(data[1][0].toString());
	driver.findElement(property.getElement("T_TRAVELLER2LNAME")).sendKeys(data[1][1].toString());
	//TRAVLLER3
	driver.findElement(property.getElement("T_TITLE3")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_MISS3")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_TRAVELLER3FNAME")).sendKeys(data[2][0].toString());
	driver.findElement(property.getElement("T_TRAVELLER3LNAME")).sendKeys(data[2][1].toString());
	Thread.sleep(3000);
	
	String number = property.getProp("T_NUMBER");
	driver.findElement(By.xpath( "//input[@id='txtCPhone']")).sendKeys(number);;
	Thread.sleep(3000);
	js.executeScript("window.scrollBy(0,document.body.scrollHeight)");//scroll down to bottom
	System.out.println("hi");
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_DAY")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_DAYY")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_MON")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_MONTH")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_YR")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_YEAR")).click();
	Thread.sleep(3000);
	driver.findElement(property.getElement("T_BOOKING")).click();
	Thread.sleep(5000);
	Assert.assertEquals(driver.getTitle(),"FlightPayment Lowest Airfare, Flight Tickets, Cheap Air Tickets � EaseMyTrip.com");
	new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@class='rev2 ac']")));
	}


}
