package testExecution;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import loginregisterpom.LoginFactory;
import loginregisterpom.SignUpFactory;
import util.Base;

public class Execute extends Base
{
	@Test(priority=1,dataProvider="LoginData")
	public void LoginTest (String UN,String PWD) throws Exception 
	{
		
		LoginFactory LF=new LoginFactory(driver);
		LF.Login( UN,PWD);
	 
	}
	

	/*	@Test(priority=2,dataProvider="Data")
	  public void SignupTest(String no,String pass,String repass) throws Exception
	  {
			SignUpFactory SF=new SignUpFactory(driver);
		  SF.SIGNUP(no,pass,repass);
		
	  }*/
	
		
	@DataProvider
		public Object[][] LoginData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("Sheet4",2 );
			return data;
		}
	
	@DataProvider
	public Object[][] Data() throws Exception
	{
		Object data[][]=excel.MyDataProvider("Sheet6",3 );
		return data;
	}

}
