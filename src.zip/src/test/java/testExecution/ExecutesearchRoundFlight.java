package testExecution;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import flightroundwaypom.FlightBookRound;
import flightroundwaypom.SearchRoundFactory;
import flightroundwaypom.EnterEmailRoundFlight;
import util.Base;
import flightroundwaypom.EnterTravellerDetails;
public class ExecutesearchRoundFlight extends Base 
{
	@Test(priority=1,dataProvider="FlightRoundWayData1")
  public void FlightRoundWayData(String source, String destination) 
  {
		SearchRoundFactory fow=new SearchRoundFactory(driver);
	   fow.flightSearch(source, destination);
  }
  
	@Test(priority=2)
	  public void FlightBookRound() 
	  {
			FlightBookRound fow=new FlightBookRound(driver);
		   fow.flightBook();
	  }
	
	@Test(priority=3,dataProvider="EnterEmail")
	  public void EnterEmailRoundFlight(String email) throws Exception 
	  {
			EnterEmailRoundFlight fow=new EnterEmailRoundFlight(driver);
		   fow.enterEmailId(email);
	  }
	
	@Test(priority=4)
	  public void EnterTravellerDetails() throws Exception 
	  {
			EnterTravellerDetails fow=new EnterTravellerDetails(driver);
		   fow.enterDetails(excel.MyDataProvider("Sheet3",2));
	  }

@DataProvider
  public Object[][] FlightRoundWayData1() throws Exception
	{
		Object data[][]=excel.MyDataProvider("Sheet1", 2);
		return data;
	}

@DataProvider
public Object[][] EnterEmail() throws Exception
	{
		Object data[][]=excel.MyDataProvider("Sheet2", 1);
		return data;
	}
@DataProvider
public Object[][] EnterTraveller() throws Exception
	{
		Object data[][]=excel.MyDataProvider("Sheet3", 2);
		return data;
	}


}
